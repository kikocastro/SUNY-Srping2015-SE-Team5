// CKeditor config is done in /app/view/js/bolt.min.js.
