RevolutionSlider extension for Bolt  [documentation](http://revolution.themepunch.com/)
=============

Slider Revolution is an all-purpose slide displaying solution that allows for showing almost any kind of content with highly customizable, transitions, effects and custom animations. Due to its visual oriented interface and countless options, Slider Revolution is suited for beginners and pro’s alike!